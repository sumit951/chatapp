import React from 'react'

const Footer = () => {
  return (
    <div>
        <footer className="footer">
            <span className="pull-right">
            Rapid Collaborate
            </span>
            Company 2015-2020
        </footer>
    </div>
  )
}

export default Footer